﻿Public Class frmPayroll
    Dim strIncome As String
    Dim decIncome As Decimal
    Dim decFica As Decimal
    Dim decFederal As Decimal
    Dim decState As Decimal
    Dim decNet As Decimal


    Private Sub ButtonTaxCalc(sender As Object, e As EventArgs) Handles btnTaxCalc.Click
        Dim CDecFica As Decimal
        Dim CDecFed As Decimal
        Dim CDecState As Decimal

        strIncome = txtIncome.Text
        decIncome = strIncome

        CDecFica = 0.0765D
        CDecFed = 0.22D
        CDecState = 0.04D
        lblFicaTax.Text = (decIncome * CDecFica).ToString("C2")
        lblStateTax.Text = (decIncome * CDecState).ToString("C2")
        lblFedTax.Text = (decIncome * CDecFed).ToString("C2")

        lblNetPaycheck.Text = (decIncome - (CDecFica + CDecState + CDecFed)).ToString("C2")




    End Sub



    Private Sub ButtonClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtIncome.Clear()
        txtIncome.Focus()
    End Sub

    Private Sub ButtonExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
